"""
AI-Powered Document Summarization System
Teyzix Core Internship (June Batch) — Task ID: AI-INT-1

Core summarization engine implementing extractive summarization using
frequency-based and TF-IDF based sentence scoring, plus supporting
analytics (word frequency, keyword extraction, sentence importance).
"""

import re
import string
from collections import Counter

import numpy as np
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import sent_tokenize, word_tokenize
from sklearn.feature_extraction.text import TfidfVectorizer

# Make sure required NLTK resources are available (no-op if already present)
for resource, path in [
    ("punkt", "tokenizers/punkt"),
    ("punkt_tab", "tokenizers/punkt_tab"),
    ("stopwords", "corpora/stopwords"),
]:
    try:
        nltk.data.find(path)
    except LookupError:
        nltk.download(resource, quiet=True)


class DocumentSummarizer:
    """
    Extractive text summarizer.

    Pipeline:
        raw text -> sentence segmentation -> tokenization / cleaning
        -> stopword removal -> sentence scoring (frequency / TF-IDF / combined)
        -> top-N sentence selection -> summary (sentences kept in original order)
    """

    def __init__(self, language: str = "english"):
        self.language = language
        self.stop_words = set(stopwords.words(language))

    # ------------------------------------------------------------------
    # Preprocessing
    # ------------------------------------------------------------------
    def clean_sentence(self, sentence: str) -> str:
        """Lowercase and strip punctuation/digits noise for vectorization."""
        sentence = sentence.lower()
        sentence = re.sub(r"[^a-z\s]", " ", sentence)
        sentence = re.sub(r"\s+", " ", sentence).strip()
        return sentence

    def tokenize_sentences(self, text: str) -> list:
        """Split raw text into sentences."""
        text = re.sub(r"\s+", " ", text.strip())
        if not text:
            return []
        return sent_tokenize(text)

    def tokenize_words(self, text: str, remove_stopwords: bool = True) -> list:
        """Lowercase, tokenize into words, drop punctuation and (optionally) stopwords."""
        words = word_tokenize(text.lower())
        words = [w for w in words if w not in string.punctuation]
        if remove_stopwords:
            words = [w for w in words if w.isalpha() and w not in self.stop_words]
        return words

    def preprocess(self, text: str) -> dict:
        """Run the full preprocessing pipeline and return key statistics."""
        sentences = self.tokenize_sentences(text)
        words = self.tokenize_words(text)
        return {
            "sentences": sentences,
            "words": words,
            "num_sentences": len(sentences),
            "num_words": len(words),
            "unique_words": len(set(words)),
        }

    # ------------------------------------------------------------------
    # Scoring approaches
    # ------------------------------------------------------------------
    def frequency_scores(self, sentences: list) -> np.ndarray:
        """
        Frequency-based scoring: score each sentence by the average
        normalized frequency of its (non-stopword) words in the document.
        """
        all_words = []
        for s in sentences:
            all_words.extend(self.tokenize_words(s))

        freq = Counter(all_words)
        max_freq = max(freq.values()) if freq else 1
        norm_freq = {w: f / max_freq for w, f in freq.items()}

        scores = []
        for s in sentences:
            s_words = self.tokenize_words(s)
            if not s_words:
                scores.append(0.0)
                continue
            score = sum(norm_freq.get(w, 0.0) for w in s_words) / len(s_words)
            scores.append(score)
        return np.array(scores)

    def tfidf_scores(self, sentences: list) -> np.ndarray:
        """TF-IDF based scoring: score each sentence by the sum of its TF-IDF weights."""
        cleaned = [self.clean_sentence(s) for s in sentences]
        if not any(cleaned):
            return np.zeros(len(sentences))

        vectorizer = TfidfVectorizer(stop_words=list(self.stop_words))
        try:
            tfidf_matrix = vectorizer.fit_transform(cleaned)
        except ValueError:
            # Happens when every sentence is empty after cleaning
            return np.zeros(len(sentences))
        return np.asarray(tfidf_matrix.sum(axis=1)).flatten()

    @staticmethod
    def _normalize(arr: np.ndarray) -> np.ndarray:
        if arr.size == 0:
            return arr
        rng = arr.max() - arr.min()
        if rng < 1e-9:
            return np.zeros_like(arr)
        return (arr - arr.min()) / rng

    def combined_scores(self, sentences: list, freq_weight: float = 0.5, tfidf_weight: float = 0.5) -> np.ndarray:
        """Blend frequency-based and TF-IDF scores (sentence ranking signal)."""
        f_scores = self._normalize(self.frequency_scores(sentences))
        t_scores = self._normalize(self.tfidf_scores(sentences))
        return freq_weight * f_scores + tfidf_weight * t_scores

    def _score_sentences(self, sentences: list, method: str) -> np.ndarray:
        if method == "frequency":
            return self.frequency_scores(sentences)
        elif method == "tfidf":
            return self.tfidf_scores(sentences)
        elif method == "combined":
            return self.combined_scores(sentences)
        else:
            raise ValueError(f"Unknown method '{method}'. Use 'frequency', 'tfidf', or 'combined'.")

    # ------------------------------------------------------------------
    # Summarization
    # ------------------------------------------------------------------
    def summarize(self, text: str, ratio: float = 0.3, num_sentences: int = None, method: str = "combined") -> dict:
        """
        Generate an extractive summary.

        Args:
            text: raw input document text.
            ratio: fraction of original sentences to keep (used if num_sentences is None).
            num_sentences: explicit number of sentences to keep (overrides ratio).
            method: 'frequency', 'tfidf', or 'combined'.

        Returns:
            dict with original text, summary, counts, compression ratio,
            per-sentence scores, and the method used.
        """
        if not isinstance(text, str) or not text.strip():
            raise ValueError("Input text is empty or invalid.")

        sentences = self.tokenize_sentences(text)
        if not sentences:
            raise ValueError("No sentences could be detected in the input text.")

        if num_sentences is None:
            if not (0 < ratio <= 1):
                raise ValueError("ratio must be between 0 (exclusive) and 1 (inclusive).")
            n = max(1, round(len(sentences) * ratio))
        else:
            if num_sentences <= 0:
                raise ValueError("num_sentences must be a positive integer.")
            n = num_sentences
        n = min(n, len(sentences))

        scores = self._score_sentences(sentences, method)

        ranked_idx = np.argsort(scores)[::-1][:n]
        keep_idx_sorted = sorted(ranked_idx.tolist())  # preserve original reading order

        summary_sentences = [sentences[i] for i in keep_idx_sorted]
        summary = " ".join(summary_sentences)

        sentence_scores = [
            {
                "sentence": sentences[i],
                "score": round(float(scores[i]), 4),
                "selected": i in keep_idx_sorted,
            }
            for i in range(len(sentences))
        ]

        return {
            "original_text": text,
            "summary": summary,
            "original_sentence_count": len(sentences),
            "summary_sentence_count": len(summary_sentences),
            "compression_ratio": round(len(summary_sentences) / len(sentences), 2),
            "sentence_scores": sentence_scores,
            "method": method,
        }

    # ------------------------------------------------------------------
    # Analytics module
    # ------------------------------------------------------------------
    def word_frequency_analysis(self, text: str, top_n: int = 15) -> list:
        """Return the top_n most frequent (non-stopword) words as (word, count) pairs."""
        words = self.tokenize_words(text)
        return Counter(words).most_common(top_n)

    def extract_keywords(self, text: str, top_n: int = 10) -> list:
        """Extract top_n keywords ranked by aggregate TF-IDF score across the document."""
        sentences = self.tokenize_sentences(text)
        cleaned = [self.clean_sentence(s) for s in sentences]
        if not any(cleaned):
            return []

        vectorizer = TfidfVectorizer(stop_words=list(self.stop_words))
        try:
            tfidf_matrix = vectorizer.fit_transform(cleaned)
        except ValueError:
            return []

        scores = np.asarray(tfidf_matrix.sum(axis=0)).flatten()
        terms = vectorizer.get_feature_names_out()
        ranked = sorted(zip(terms, scores), key=lambda x: x[1], reverse=True)
        return [(term, round(float(score), 4)) for term, score in ranked[:top_n]]

    def sentence_importance(self, text: str, method: str = "combined") -> list:
        """Return all sentences ranked by importance score, highest first."""
        sentences = self.tokenize_sentences(text)
        scores = self._score_sentences(sentences, method)
        ranked = sorted(zip(sentences, scores), key=lambda x: x[1], reverse=True)
        return [(s, round(float(sc), 4)) for s, sc in ranked]
