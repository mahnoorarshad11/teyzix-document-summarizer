# AI-Powered Document Summarization System

**Teyzix Core Internship (June Batch)** · Task ID: `AI-INT-1` · Domain: Artificial Intelligence / NLP

An extractive text summarization system that condenses long documents (text files, PDFs, or pasted input) into short, meaningful summaries while preserving key information — complete with a word-frequency and keyword analytics module and an interactive Streamlit front end.

## Overview

Organizations deal with large volumes of documents — reports, emails, articles — and manual summarization is slow and inconsistent. This system automates the process using **extractive summarization**: rather than generating new sentences, it identifies and pulls out the most important sentences already present in the source text, based on word frequency and TF-IDF scoring.

The project is split into four parts:

- `summarizer.py` — the core NLP engine (preprocessing, scoring, summarization, analytics)
- `utils.py` — file handling (load `.txt`/`.pdf`, export summaries as `.txt`/`.pdf`)
- `main.py` — a command-line demo that runs the pipeline on sample documents
- `app.py` — a Streamlit web UI for live, interactive summarization (bonus deliverable)

## Pipeline

| Stage | Step | Description |
|---|---|---|
| 1 | Data Input | Accepts text from a `.txt` file, a `.pdf` file, or direct/pasted text |
| 2 | Preprocessing | Lowercasing, sentence segmentation (`nltk.sent_tokenize`), word tokenization, stopword removal |
| 3 | Scoring | Each sentence is scored using **frequency-based**, **TF-IDF based**, or a **combined** approach |
| 4 | Ranking & Selection | Sentences are ranked by score; the top N are selected and reassembled in their original order |
| 5 | Output | Final summary, shown side-by-side with the original text, with an adjustable length (ratio or sentence count) |
| 6 | Analytics | Word frequency analysis, keyword extraction (TF-IDF), and full sentence-importance ranking |
| 7 | Export | Summary can be saved as `.txt` or `.pdf` |

## Algorithm Explanation

**Frequency-based scoring** builds a word-frequency table across the whole document (after removing stopwords), normalizes it by the most frequent word, and scores each sentence as the average normalized frequency of its words. Sentences built from commonly repeated, content-bearing words score higher.

**TF-IDF based scoring** vectorizes every sentence with `TfidfVectorizer` (scikit-learn), treating each sentence as a mini-document within the larger text. A sentence's score is the sum of its TF-IDF weights — this naturally favors sentences containing words that are frequent *within the document* but distinctive relative to common sentence structure, rather than just frequent in general.

**Combined scoring** (the default) min-max normalizes both signals and averages them, which tends to be more robust than either signal alone — frequency favors recurring themes, TF-IDF favors distinctive/informative phrasing.

Once every sentence has a score, the system selects the top-N highest-scoring sentences (N derived from either a percentage ratio or an explicit count) and reassembles them **in their original order** so the summary still reads coherently.

## Requirements

- Python 3.10+
- See `requirements.txt`:
  - `nltk` — sentence/word tokenization, stopwords
  - `scikit-learn` — TF-IDF vectorization
  - `numpy` — scoring math
  - `PyPDF2` — PDF text extraction
  - `fpdf2` — PDF export
  - `streamlit`, `pandas` — web UI and analytics tables

Install everything with:

```bash
pip install -r requirements.txt
```

The first run will download two small NLTK data packages (`punkt`, `stopwords`) automatically if they aren't already present.

## Usage

### 1. Command-line demo

Runs the full pipeline on the bundled sample documents and prints original text, summary, word frequencies, and keywords; also saves summaries to `generated_summaries/`.

```bash
python main.py
```

### 2. Web app (Streamlit)

```bash
streamlit run app.py
```

This opens an interactive UI where you can:
- Paste text, or upload a `.txt`/`.pdf` file
- Choose the scoring method (`combined` / `frequency` / `tfidf`)
- Adjust summary length by percentage or exact sentence count
- View original vs. summary side-by-side
- Browse the analytics module (word frequency chart, keyword table, sentence-importance ranking)
- Download the summary as `.txt` or `.pdf`

### 3. Using the engine directly in code

```python
from summarizer import DocumentSummarizer
from utils import load_document, export_summary_txt

summarizer = DocumentSummarizer()
text = load_document("sample_documents/sample_climate_change.txt")

result = summarizer.summarize(text, ratio=0.3, method="combined")
print(result["summary"])

export_summary_txt(result["summary"], "output/my_summary.txt")
```

## Sample Output

Input: `sample_documents/sample_climate_change.txt` (17 sentences) → summarized at 30% (`combined` method, 5 sentences):

> Scientists attribute much of this warming to the increased concentration of greenhouse gases in the atmosphere, primarily carbon dioxide released through the burning of fossil fuels. Renewable energy sources such as solar and wind power are being adopted at a rapid pace, replacing traditional fossil fuel based power generation. International agreements, such as the Paris Agreement, set targets for nations to limit global temperature rise and encourage cooperation between countries to address the crisis collectively. Looking ahead, addressing climate change will require coordinated action across multiple sectors, including energy, transportation, agriculture, and urban planning. Ultimately, the pace and scale of global response in the coming decades will determine the severity of climate impacts faced by future generations.

Top keywords (TF-IDF): `climate (0.95), change (0.82), carbon (0.82), scale (0.70), global (0.64), energy (0.64)`

Full console output for both sample documents (including the AI-in-business sample) is saved in `execution_output.txt`.

## File Structure

```
teyzix_summarizer/
├── summarizer.py              # Core NLP engine: preprocessing, scoring, summarization, analytics
├── utils.py                   # File I/O: load .txt/.pdf, export summary as .txt/.pdf
├── main.py                    # CLI demo script
├── app.py                     # Streamlit web UI (bonus deliverable)
├── requirements.txt
├── README.md
├── execution_output.txt       # Captured console output from running main.py
├── sample_documents/
│   ├── sample_climate_change.txt
│   └── sample_ai_in_business.txt
└── generated_summaries/       # Output summaries created by main.py
    ├── sample_climate_change_summary.txt
    └── sample_ai_in_business_summary.txt
```

## Key Concepts

- **Extractive vs. abstractive summarization**: this system is extractive — it selects existing sentences rather than generating new text. (Abstractive summarization via Transformers is listed as a bonus challenge and is a natural extension using a model such as a BART or T5 pipeline.)
- **Stopwords**: common low-information words ("the", "is", "and") that are removed before scoring so that scoring reflects content words.
- **TF-IDF (Term Frequency–Inverse Document Frequency)**: a weighting scheme that boosts words frequent in a specific sentence but rarer across the whole document — capturing distinctive, informative content.
- **Sentence ranking**: sentences are scored independently, then the highest-scoring N are kept and re-ordered to match their original position, preserving narrative flow in the summary.
- **Compression ratio**: the proportion of original sentences retained in the summary (e.g., 0.29 means the summary is 29% the length of the original, by sentence count).
- **Modular design**: scoring, preprocessing, file I/O, and the UI are all separated into independent functions/files, so any one part (e.g., swapping in a different scoring method) can be modified without touching the rest.

## Error Handling

The system raises clear, descriptive errors rather than failing silently:
- Empty or invalid input text → `ValueError`
- No sentences detected in input → `ValueError`
- Missing input file → `FileNotFoundError`
- Unsupported file extension (anything other than `.txt`/`.pdf`) → `ValueError`
- Scanned/image-only PDFs with no extractable text → `ValueError` with a clear message
- Invalid `ratio` or `num_sentences` arguments → `ValueError`

## Notes on Deliverables

- **Execution screenshots**: this build was verified by running `main.py` end-to-end (output captured in `execution_output.txt`) and by booting `app.py` with Streamlit to confirm the UI loads with no runtime errors. Since the Streamlit UI is a live local web app, run `streamlit run app.py` on your machine to view and screenshot it interactively for submission.
- **Bonus challenges not yet implemented**: abstractive summarization (Transformers), multi-document summarization, and language detection are good next extensions — the modular structure makes them straightforward to add as additional methods on `DocumentSummarizer`.
