"""
Command-line demo for the AI-Powered Document Summarization System.

Run this script to see the summarizer in action on the bundled sample
documents. It prints original vs. summarized text, analytics, and saves
generated summaries to the generated_summaries/ folder.

Usage:
    python main.py
"""

from pathlib import Path

from summarizer import DocumentSummarizer
from utils import load_document, export_summary_txt

BASE_DIR = Path(__file__).parent
SAMPLE_DIR = BASE_DIR / "sample_documents"
OUTPUT_DIR = BASE_DIR / "generated_summaries"


def run_demo():
    summarizer = DocumentSummarizer()
    OUTPUT_DIR.mkdir(exist_ok=True)

    sample_files = sorted(SAMPLE_DIR.glob("*.txt"))
    if not sample_files:
        print("No sample documents found in sample_documents/")
        return

    for file_path in sample_files:
        print("=" * 78)
        print(f"PROCESSING: {file_path.name}")
        print("=" * 78)

        try:
            text = load_document(file_path)
            stats = summarizer.preprocess(text)
            result = summarizer.summarize(text, ratio=0.3, method="combined")
        except (ValueError, FileNotFoundError) as e:
            print(f"[ERROR] {e}")
            continue

        print(f"\nOriginal sentences   : {stats['num_sentences']}")
        print(f"Total words (clean)  : {stats['num_words']}")
        print(f"Unique words         : {stats['unique_words']}")
        print(f"\nSummary sentences    : {result['summary_sentence_count']}")
        print(f"Compression ratio    : {result['compression_ratio']} "
              f"({result['compression_ratio']*100:.0f}% of original)")

        print("\n--- ORIGINAL TEXT (first 200 chars) ---")
        print(text.strip().replace("\n", " ")[:200] + "...")

        print("\n--- GENERATED SUMMARY ---")
        print(result["summary"])

        freq = summarizer.word_frequency_analysis(text, top_n=8)
        print("\n--- TOP WORD FREQUENCIES ---")
        print(", ".join(f"{w} ({c})" for w, c in freq))

        keywords = summarizer.extract_keywords(text, top_n=8)
        print("\n--- TOP KEYWORDS (TF-IDF) ---")
        print(", ".join(f"{w} ({s:.2f})" for w, s in keywords))

        out_path = OUTPUT_DIR / f"{file_path.stem}_summary.txt"
        export_summary_txt(result["summary"], out_path)
        print(f"\n[Saved summary to: {out_path}]")
        print()


if __name__ == "__main__":
    run_demo()
