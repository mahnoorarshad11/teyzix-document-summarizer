"""
File handling utilities for the AI-Powered Document Summarization System.

Supports:
    - Loading input documents from .txt and .pdf files
    - Exporting generated summaries as .txt or .pdf files
"""

from pathlib import Path


def load_text_file(file_path) -> str:
    """Load raw text from a .txt file."""
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")
    return path.read_text(encoding="utf-8", errors="ignore")


def load_pdf_file(file_path) -> str:
    """Extract raw text from a .pdf file."""
    try:
        from PyPDF2 import PdfReader
    except ImportError as e:
        raise ImportError(
            "PyPDF2 is required to load PDF files. Install with: pip install PyPDF2"
        ) from e

    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")

    reader = PdfReader(str(path))
    text_parts = [page.extract_text() or "" for page in reader.pages]
    full_text = "\n".join(text_parts).strip()

    if not full_text:
        raise ValueError(
            "No extractable text found in PDF (it may be a scanned/image-only document)."
        )
    return full_text


def load_document(file_path) -> str:
    """Dispatch to the correct loader based on file extension (.txt or .pdf)."""
    path = Path(file_path)
    suffix = path.suffix.lower()
    if suffix == ".txt":
        return load_text_file(path)
    elif suffix == ".pdf":
        return load_pdf_file(path)
    else:
        raise ValueError(f"Unsupported file type: '{suffix}'. Use .txt or .pdf")


def export_summary_txt(summary_text: str, output_path) -> str:
    """Save a summary as a plain text file. Returns the saved path."""
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(summary_text, encoding="utf-8")
    return str(path)


def export_summary_pdf(summary_text: str, output_path, title: str = "Document Summary") -> str:
    """Save a summary as a simple formatted PDF file. Returns the saved path."""
    try:
        from fpdf import FPDF
    except ImportError as e:
        raise ImportError(
            "fpdf2 is required to export PDF files. Install with: pip install fpdf2"
        ) from e

    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)

    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Helvetica", "B", 16)
    pdf.cell(0, 10, title, new_x="LMARGIN", new_y="NEXT")
    pdf.ln(4)
    pdf.set_font("Helvetica", "", 11)
    pdf.multi_cell(0, 7, summary_text)
    pdf.output(str(path))
    return str(path)
