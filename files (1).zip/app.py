"""
Streamlit frontend for the AI-Powered Document Summarization System.
Teyzix Core Internship (June Batch) — Task ID: AI-INT-1 (Bonus: Streamlit UI)

Run with:
    streamlit run app.py
"""

from pathlib import Path

import pandas as pd
import streamlit as st

from summarizer import DocumentSummarizer
from utils import load_pdf_file, export_summary_pdf

st.set_page_config(page_title="AI Document Summarizer", page_icon="📄", layout="wide")


@st.cache_resource
def get_summarizer():
    return DocumentSummarizer()


summarizer = get_summarizer()

st.title("📄 AI-Powered Document Summarization System")
st.caption("Extractive summarization using frequency-based and TF-IDF sentence scoring · Teyzix Core Internship")

# ---------------------------------------------------------------------------
# Sidebar settings
# ---------------------------------------------------------------------------
with st.sidebar:
    st.header("⚙️ Settings")
    method = st.selectbox(
        "Summarization method",
        ["combined", "frequency", "tfidf"],
        index=0,
        help="combined blends frequency and TF-IDF scores for ranking sentences.",
    )

    length_mode = st.radio("Summary length mode", ["By percentage", "By sentence count"])
    if length_mode == "By percentage":
        ratio = st.slider("Summary length (% of original)", 10, 70, 30) / 100
        num_sentences = None
    else:
        ratio = 0.3
        num_sentences = st.number_input("Number of sentences", min_value=1, max_value=50, value=3)

    st.divider()
    show_analytics = st.checkbox("Show analytics module", value=True)
    st.divider()
    st.caption("Task ID: AI-INT-1 · Teyzix Core Internship")

# ---------------------------------------------------------------------------
# Input section
# ---------------------------------------------------------------------------
st.subheader("1. Input Document")
input_mode = st.radio("Choose input method", ["Paste text", "Upload .txt", "Upload .pdf"], horizontal=True)

text = ""
if input_mode == "Paste text":
    text = st.text_area("Paste your text here", height=220, placeholder="Paste an article, report, or email here...")
elif input_mode == "Upload .txt":
    uploaded = st.file_uploader("Upload a text file", type=["txt"])
    if uploaded:
        text = uploaded.read().decode("utf-8", errors="ignore")
elif input_mode == "Upload .pdf":
    uploaded = st.file_uploader("Upload a PDF file", type=["pdf"])
    if uploaded:
        temp_path = Path("temp_upload.pdf")
        temp_path.write_bytes(uploaded.getbuffer())
        try:
            text = load_pdf_file(temp_path)
        except Exception as e:
            st.error(f"Could not read PDF: {e}")
        finally:
            temp_path.unlink(missing_ok=True)

if text:
    with st.expander("Preview loaded text"):
        st.write(text[:1500] + ("..." if len(text) > 1500 else ""))

run = st.button("✨ Generate Summary", type="primary")

# ---------------------------------------------------------------------------
# Output section
# ---------------------------------------------------------------------------
if run:
    if not text or not text.strip():
        st.error("Please provide some text first (paste, or upload a .txt/.pdf file).")
    else:
        try:
            result = summarizer.summarize(text, ratio=ratio, num_sentences=num_sentences, method=method)
        except ValueError as e:
            st.error(f"Could not generate summary: {e}")
        else:
            st.subheader("2. Original vs. Summary")
            m1, m2, m3 = st.columns(3)
            m1.metric("Original sentences", result["original_sentence_count"])
            m2.metric("Summary sentences", result["summary_sentence_count"])
            m3.metric("Compression", f"{result['compression_ratio']*100:.0f}%")

            col1, col2 = st.columns(2)
            with col1:
                st.markdown("**Original text**")
                st.text_area("original", value=result["original_text"], height=300, disabled=True, label_visibility="collapsed")
            with col2:
                st.markdown("**Generated summary**")
                st.text_area("summary", value=result["summary"], height=300, disabled=True, label_visibility="collapsed")

            dl1, dl2 = st.columns(2)
            with dl1:
                st.download_button("⬇️ Download summary (.txt)", result["summary"], file_name="summary.txt")
            with dl2:
                pdf_path = export_summary_pdf(result["summary"], "generated_summary.pdf")
                with open(pdf_path, "rb") as f:
                    st.download_button("⬇️ Download summary (.pdf)", f, file_name="summary.pdf")

            if show_analytics:
                st.subheader("3. Analytics Module")
                tab1, tab2, tab3 = st.tabs(["📊 Word Frequency", "🔑 Keywords", "📈 Sentence Importance"])

                with tab1:
                    freq = summarizer.word_frequency_analysis(text, top_n=15)
                    if freq:
                        df_freq = pd.DataFrame(freq, columns=["Word", "Frequency"])
                        st.bar_chart(df_freq.set_index("Word"))
                    else:
                        st.info("Not enough content for frequency analysis.")

                with tab2:
                    keywords = summarizer.extract_keywords(text, top_n=12)
                    if keywords:
                        df_kw = pd.DataFrame(keywords, columns=["Keyword", "TF-IDF Score"])
                        st.dataframe(df_kw, use_container_width=True, hide_index=True)
                    else:
                        st.info("Not enough content for keyword extraction.")

                with tab3:
                    ranked = summarizer.sentence_importance(text, method=method)
                    df_rank = pd.DataFrame(ranked, columns=["Sentence", "Importance Score"])
                    st.dataframe(df_rank, use_container_width=True, hide_index=True)
else:
    st.info("Paste or upload a document, adjust settings in the sidebar, then click **Generate Summary**.")
